# Installation
Read manual

# Compiling
To compile the program simply do:

    make

This will compile the program and move the executable to the 'bin' folder.